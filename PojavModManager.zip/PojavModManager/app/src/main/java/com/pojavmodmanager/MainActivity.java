package com.pojavmodmanager;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.view.KeyEvent;
import android.view.inputmethod.EditorInfo;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.util.ArrayList;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class MainActivity extends AppCompatActivity {

    ListView listMods;
    Button btnSearch, btnTabModrinth, btnTabCurseForge;
    EditText etSearch;
    Spinner spinnerInstance;
    TextView tvStatus;

    String POJAV_PATH = "/storage/emulated/0/games/PojavLauncher/";
    String CURSEFORGE_API_KEY = ""; // Add your key here later
    String currentSource = "modrinth";

    ArrayList<ModItem> modItems = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listMods = findViewById(R.id.listMods);
        btnSearch = findViewById(R.id.btnSearch);
        etSearch = findViewById(R.id.etSearch);
        spinnerInstance = findViewById(R.id.spinnerInstance);
        tvStatus = findViewById(R.id.tvStatus);
        btnTabModrinth = findViewById(R.id.btnTabModrinth);
        btnTabCurseForge = findViewById(R.id.btnTabCurseForge);

        requestPermissions();
        loadInstances();
        setupTabs();

        btnSearch.setOnClickListener(v -> search());

        // Search on keyboard "done"
        etSearch.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEARCH ||
                (event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER)) {
                search();
                return true;
            }
            return false;
        });
    }

    void setupTabs() {
        btnTabModrinth.setOnClickListener(v -> {
            currentSource = "modrinth";
            btnTabModrinth.setBackgroundTintList(
                android.content.res.ColorStateList.valueOf(0xFF6200EA));
            btnTabCurseForge.setBackgroundTintList(
                android.content.res.ColorStateList.valueOf(0xFF2A2A3E));
            tvStatus.setText("Source: Modrinth");
        });

        btnTabCurseForge.setOnClickListener(v -> {
            currentSource = "curseforge";
            btnTabCurseForge.setBackgroundTintList(
                android.content.res.ColorStateList.valueOf(0xFFFF6B35));
            btnTabModrinth.setBackgroundTintList(
                android.content.res.ColorStateList.valueOf(0xFF2A2A3E));
            if (CURSEFORGE_API_KEY.isEmpty()) {
                tvStatus.setText("⚠ CurseForge needs API Key (set in MainActivity.java)");
            } else {
                tvStatus.setText("Source: CurseForge");
            }
        });
    }

    void search() {
        String query = etSearch.getText().toString().trim();
        if (query.isEmpty()) {
            tvStatus.setText("⚠ Please enter a mod name.");
            return;
        }

        tvStatus.setText("🔍 Searching " + currentSource + "...");
        modItems.clear();
        updateList();

        if (currentSource.equals("modrinth")) {
            searchModrinth(query);
        } else {
            searchCurseForge(query);
        }
    }

    void loadInstances() {
        File instancesDir = new File(POJAV_PATH + "instances/");
        ArrayList<String> instances = new ArrayList<>();
        instances.add("Default");

        if (instancesDir.exists() && instancesDir.listFiles() != null) {
            for (File f : instancesDir.listFiles()) {
                if (f.isDirectory()) {
                    instances.add(f.getName());
                }
            }
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
            android.R.layout.simple_spinner_dropdown_item, instances);
        spinnerInstance.setAdapter(adapter);
    }

    void searchModrinth(String query) {
        new Thread(() -> {
            try {
                OkHttpClient client = new OkHttpClient();
                String encodedQuery = query.replace(" ", "%20");
                String url = "https://api.modrinth.com/v2/search"
                    + "?query=" + encodedQuery
                    + "&limit=20"
                    + "&facets=[[\"project_type:mod\"]]";

                Request request = new Request.Builder()
                    .url(url)
                    .addHeader("User-Agent", "PojavModManager/1.0")
                    .build();

                Response response = client.newCall(request).execute();
                String body = response.body().string();

                JSONObject json = new JSONObject(body);
                JSONArray hits = json.getJSONArray("hits");

                modItems.clear();
                for (int i = 0; i < hits.length(); i++) {
                    JSONObject mod = hits.getJSONObject(i);
                    String name = mod.getString("title");
                    String desc = mod.optString("description", "No description");
                    String slug = mod.getString("slug");

                    // Build requirements string
                    JSONArray loaders = mod.optJSONArray("loaders");
                    JSONArray gameVersions = mod.optJSONArray("game_versions");

                    StringBuilder loadersStr = new StringBuilder();
                    if (loaders != null) {
                        for (int j = 0; j < loaders.length(); j++) {
                            if (j > 0) loadersStr.append(", ");
                            loadersStr.append(capitalize(loaders.getString(j)));
                        }
                    }

                    String latestVersion = "";
                    if (gameVersions != null && gameVersions.length() > 0) {
                        latestVersion = gameVersions.getString(gameVersions.length() - 1);
                    }

                    String requires = "Loader: " + (loadersStr.length() > 0 ? loadersStr : "Unknown")
                        + "  |  MC: " + (latestVersion.isEmpty() ? "?" : latestVersion);

                    modItems.add(new ModItem(name, desc, requires, slug, "modrinth"));
                }

                String finalMsg = "Found " + modItems.size() + " mods on Modrinth";
                runOnUiThread(() -> {
                    tvStatus.setText(finalMsg);
                    updateList();
                });

            } catch (Exception e) {
                runOnUiThread(() -> tvStatus.setText("❌ Error: " + e.getMessage()));
            }
        }).start();
    }

    void searchCurseForge(String query) {
        if (CURSEFORGE_API_KEY.isEmpty()) {
            tvStatus.setText("❌ No CurseForge API Key. Add it in MainActivity.java");
            return;
        }

        new Thread(() -> {
            try {
                OkHttpClient client = new OkHttpClient();
                String encodedQuery = query.replace(" ", "%20");
                String url = "https://api.curseforge.com/v1/mods/search"
                    + "?gameId=432"
                    + "&searchFilter=" + encodedQuery
                    + "&pageSize=20";

                Request request = new Request.Builder()
                    .url(url)
                    .addHeader("x-api-key", CURSEFORGE_API_KEY)
                    .addHeader("Accept", "application/json")
                    .build();

                Response response = client.newCall(request).execute();
                String body = response.body().string();

                JSONObject json = new JSONObject(body);
                JSONArray data = json.getJSONArray("data");

                modItems.clear();
                for (int i = 0; i < data.length(); i++) {
                    JSONObject mod = data.getJSONObject(i);
                    String name = mod.getString("name");
                    String desc = mod.optString("summary", "No description");
                    String id = String.valueOf(mod.getInt("id"));

                    // Latest game version
                    JSONArray versions = mod.optJSONArray("latestFilesIndexes");
                    String latestMC = "?";
                    if (versions != null && versions.length() > 0) {
                        latestMC = versions.getJSONObject(0).optString("gameVersion", "?");
                    }

                    String requires = "MC: " + latestMC + "  |  Check page for loader";
                    modItems.add(new ModItem(name, desc, requires, id, "curseforge"));
                }

                String finalMsg = "Found " + modItems.size() + " mods on CurseForge";
                runOnUiThread(() -> {
                    tvStatus.setText(finalMsg);
                    updateList();
                });

            } catch (Exception e) {
                runOnUiThread(() -> tvStatus.setText("❌ CurseForge Error: " + e.getMessage()));
            }
        }).start();
    }

    void updateList() {
        String instance = spinnerInstance.getSelectedItem() != null
            ? spinnerInstance.getSelectedItem().toString() : "Default";
        ModAdapter adapter = new ModAdapter(this, modItems, instance, POJAV_PATH);
        listMods.setAdapter(adapter);
    }

    void requestPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                    new String[]{
                        Manifest.permission.READ_EXTERNAL_STORAGE,
                        Manifest.permission.WRITE_EXTERNAL_STORAGE
                    }, 1);
            }
        }
    }

    String capitalize(String s) {
        if (s == null || s.isEmpty()) return s;
        return Character.toUpperCase(s.charAt(0)) + s.substring(1);
    }
}
