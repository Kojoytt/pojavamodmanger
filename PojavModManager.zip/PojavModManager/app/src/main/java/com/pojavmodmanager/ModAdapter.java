package com.pojavmodmanager;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class ModAdapter extends ArrayAdapter<ModItem> {

    private String instanceName;
    private String pojavPath;

    public ModAdapter(Context ctx, ArrayList<ModItem> items, String instance, String path) {
        super(ctx, R.layout.item_mod, items);
        this.instanceName = instance;
        this.pojavPath = path;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.item_mod, parent, false);
        }

        ModItem mod = getItem(position);

        TextView tvName = convertView.findViewById(R.id.tvModName);
        TextView tvReq = convertView.findViewById(R.id.tvRequirements);
        TextView tvDesc = convertView.findViewById(R.id.tvDescription);
        TextView tvSource = convertView.findViewById(R.id.tvSource);
        TextView tvStatus = convertView.findViewById(R.id.tvDownloadStatus);
        Button btnDownload = convertView.findViewById(R.id.btnDownload);

        tvName.setText(mod.name);
        tvReq.setText("🔧 " + mod.requirements);
        tvDesc.setText(mod.description);
        tvSource.setText(mod.source.toUpperCase());
        tvStatus.setText("");

        if (mod.source.equals("curseforge")) {
            tvSource.setBackgroundColor(0xFFFF6B35);
            btnDownload.setText("⚠ Need API Key");
            btnDownload.setBackgroundTintList(
                android.content.res.ColorStateList.valueOf(0xFF555555));
            btnDownload.setOnClickListener(v ->
                Toast.makeText(getContext(),
                    "CurseForge needs an API Key.\nAdd it in Settings.",
                    Toast.LENGTH_LONG).show()
            );
        } else {
            tvSource.setBackgroundColor(0xFF03DAC5);
            btnDownload.setText("⬇ Download");
            btnDownload.setBackgroundTintList(
                android.content.res.ColorStateList.valueOf(0xFF03DAC5));
            btnDownload.setOnClickListener(v -> {
                tvStatus.setText("⏳ Fetching...");
                btnDownload.setEnabled(false);
                downloadFromModrinth(mod, tvStatus, btnDownload);
            });
        }

        return convertView;
    }

    private void downloadFromModrinth(ModItem mod, TextView tvStatus, Button btnDownload) {
        new Thread(() -> {
            try {
                OkHttpClient client = new OkHttpClient();

                // Get versions list
                String versionUrl = "https://api.modrinth.com/v2/project/" + mod.id + "/version";
                Request req = new Request.Builder()
                    .url(versionUrl)
                    .addHeader("User-Agent", "PojavModManager/1.0")
                    .build();
                Response res = client.newCall(req).execute();
                String body = res.body().string();

                JSONArray versions = new JSONArray(body);
                if (versions.length() == 0) {
                    showMsg("No versions found for " + mod.name, tvStatus, btnDownload);
                    return;
                }

                JSONObject latest = versions.getJSONObject(0);
                JSONArray files = latest.getJSONArray("files");

                // Pick .jar file
                String downloadUrl = null;
                String fileName = null;
                for (int i = 0; i < files.length(); i++) {
                    JSONObject f = files.getJSONObject(i);
                    String fname = f.getString("filename");
                    if (fname.endsWith(".jar")) {
                        downloadUrl = f.getString("url");
                        fileName = fname;
                        break;
                    }
                }

                if (downloadUrl == null) {
                    showMsg("No .jar file found", tvStatus, btnDownload);
                    return;
                }

                // Determine mods folder path
                String modsPath;
                if (instanceName.equals("Default") || instanceName.equals("default")) {
                    modsPath = pojavPath + ".minecraft/mods/";
                } else {
                    modsPath = pojavPath + "instances/" + instanceName + "/.minecraft/mods/";
                }

                File modsDir = new File(modsPath);
                if (!modsDir.exists()) {
                    modsDir.mkdirs();
                }

                // Check if already downloaded
                File destFile = new File(modsPath + fileName);
                if (destFile.exists()) {
                    showMsg("✅ Already downloaded!", tvStatus, btnDownload);
                    return;
                }

                // Download the file
                final String finalFileName = fileName;
                ((Activity) getContext()).runOnUiThread(() ->
                    tvStatus.setText("⬇ Downloading..."));

                URL url = new URL(downloadUrl);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.connect();

                InputStream in = conn.getInputStream();
                FileOutputStream out = new FileOutputStream(destFile);
                byte[] buffer = new byte[8192];
                int n;
                while ((n = in.read(buffer)) != -1) {
                    out.write(buffer, 0, n);
                }
                in.close();
                out.close();

                ((Activity) getContext()).runOnUiThread(() -> {
                    tvStatus.setText("✅ Done!");
                    btnDownload.setEnabled(true);
                    btnDownload.setText("✅ Downloaded");
                    Toast.makeText(getContext(),
                        finalFileName + "\nSaved to: " + instanceName,
                        Toast.LENGTH_LONG).show();
                });

            } catch (Exception e) {
                showMsg("❌ Error: " + e.getMessage(), tvStatus, btnDownload);
            }
        }).start();
    }

    private void showMsg(String msg, TextView tvStatus, Button btnDownload) {
        ((Activity) getContext()).runOnUiThread(() -> {
            tvStatus.setText(msg);
            btnDownload.setEnabled(true);
        });
    }
}
