# Pojav Mod Manager 🎮

تطبيق لتحميل mods مباشرة لـ Pojav Launcher من Modrinth و CurseForge

## كيف تفتحه في Android Studio

1. افتح Android Studio
2. اضغط **Open**
3. اختر مجلد **PojavModManager**
4. انتظر حتى يخلص الـ Sync
5. اضغط **Run** ▶

## ميزات التطبيق ✅

- 🔍 بحث في Modrinth (يشتغل مباشرة)
- 🔍 بحث في CurseForge (يحتاج API Key)
- 📁 اختيار الـ Instance اللي تبغها
- ⬇ تحميل الـ mod مباشرة لمجلد Pojav
- 🔧 يعرض المتطلبات (Loader + نسخة MC)

## إضافة CurseForge API Key

1. روح: https://console.curseforge.com
2. سجل حساب وأنشئ API Key مجاني
3. افتح ملف: `app/src/main/java/com/pojavmodmanager/MainActivity.java`
4. ابحث عن السطر: `String CURSEFORGE_API_KEY = "";`
5. احط مفتاحك بين الـ quotes

## مسار Pojav

المسار الافتراضي:
```
/storage/emulated/0/games/PojavLauncher/
```

لو مختلف عندك، غيره في `MainActivity.java`:
```java
String POJAV_PATH = "/storage/emulated/0/games/PojavLauncher/";
```
